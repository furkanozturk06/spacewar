﻿using SpaceShooter.resources;
using SpaceShooter.utils;

namespace SpaceShooter.core
{
    public abstract class Ammunition : CollidableItem
    {
        

        public Ammunition() { }

        protected override void checkTargetCollided()
        {
            if (Target == null)
                return;

            if (!Target.IsActive)
            {
                Target = null;
                return;
            }

            if (GameGrid.ItemsIntersect(this, Target))
            {
                
                Target.TakeDamage(damage);
                IsActive = false;
            }
        }
    }
}
