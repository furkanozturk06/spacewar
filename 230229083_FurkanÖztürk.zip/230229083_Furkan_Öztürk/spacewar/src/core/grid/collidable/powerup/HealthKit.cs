﻿using SpaceShooter.resources;
using SpaceShooter.utils;

namespace SpaceShooter.core
{
    public class HealthKit : PowerUp
    {
        
        protected readonly int health;

        public HealthKit(GameGrid grid, IGridItem source, int health = 100) : base(grid, source)
        {
            this.health = health;
            Image = Resources.img_health_kit;
        }

        protected override void checkTargetCollided()
        {
            if (Target == null)
                return;

            if (!Target.IsActive)
            {
                Target = null;
                return;
            }

            if (GameGrid.ItemsIntersect(this, Target))
            {
                
                Target.RestoreHealth(health);
                IsActive = false;
            }
        }
    }
}
