﻿

namespace SpaceShooter.resources {
    using System;
    
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    internal class Resources {
        
        private static global::System.Resources.ResourceManager resourceMan;
        
        private static global::System.Globalization.CultureInfo resourceCulture;
        
        [global::System.Diagnostics.CodeAnalysis.SuppressMessageAttribute("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal Resources() {
        }
        
        
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Resources.ResourceManager ResourceManager {
            get {
                if (object.ReferenceEquals(resourceMan, null)) {
                    global::System.Resources.ResourceManager temp = new global::System.Resources.ResourceManager("SpaceShooter.resources.Resources", typeof(Resources).Assembly);
                    resourceMan = temp;
                }
                return resourceMan;
            }
        }
        
        
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Globalization.CultureInfo Culture {
            get {
                return resourceCulture;
            }
            set {
                resourceCulture = value;
            }
        }
        
        
        internal static System.Drawing.Bitmap img_blue_laser_blast {
            get {
                object obj = ResourceManager.GetObject("img_blue_laser_blast", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
       
        internal static System.Drawing.Bitmap img_enemy_bomber_spaceship {
            get {
                object obj = ResourceManager.GetObject("img_enemy_bomber_spaceship", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_enemy_boss_spaceship {
            get {
                object obj = ResourceManager.GetObject("img_enemy_boss_spaceship", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_enemy_fighter_spaceship {
            get {
                object obj = ResourceManager.GetObject("img_enemy_fighter_spaceship", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_enemy_missile {
            get {
                object obj = ResourceManager.GetObject("img_enemy_missile", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_enemy_teleporter_spaceship {
            get {
                object obj = ResourceManager.GetObject("img_enemy_teleporter_spaceship", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_explosion {
            get {
                object obj = ResourceManager.GetObject("img_explosion", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_health_kit {
            get {
                object obj = ResourceManager.GetObject("img_health_kit", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
      
        internal static System.Drawing.Bitmap img_hero_spaceship {
            get {
                object obj = ResourceManager.GetObject("img_hero_spaceship", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_kapakk {
            get {
                object obj = ResourceManager.GetObject("img_kapakk", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_red_laser_blast {
            get {
                object obj = ResourceManager.GetObject("img_red_laser_blast", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_space_background {
            get {
                object obj = ResourceManager.GetObject("img_space_background", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
        
        
        internal static System.Drawing.Bitmap img_space_background_v {
            get {
                object obj = ResourceManager.GetObject("img_space_background_v", resourceCulture);
                return ((System.Drawing.Bitmap)(obj));
            }
        }
    }
}
