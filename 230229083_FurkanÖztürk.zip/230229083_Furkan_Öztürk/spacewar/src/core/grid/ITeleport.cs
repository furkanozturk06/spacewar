﻿namespace SpaceShooter.core
{
    public interface ITeleport
    {
        public void Teleport();
    }
}
