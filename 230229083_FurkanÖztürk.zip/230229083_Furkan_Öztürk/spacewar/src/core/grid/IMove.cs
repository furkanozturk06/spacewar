﻿namespace SpaceShooter.core
{
    public interface IMove
    {
        public void Move();
    }
}
